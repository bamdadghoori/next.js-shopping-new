"use strict";
exports.id = 655;
exports.ids = [655];
exports.modules = {

/***/ 4655:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$V": () => (/* binding */ IncrementCountCustomerLot),
/* harmony export */   "Kk": () => (/* binding */ GetLotsRequest),
/* harmony export */   "LZ": () => (/* binding */ AddCustomerLot),
/* harmony export */   "f_": () => (/* binding */ GetLotsSuccess),
/* harmony export */   "iK": () => (/* binding */ DecrementCountCustomerLot),
/* harmony export */   "ls": () => (/* binding */ GetLotsFail),
/* harmony export */   "sP": () => (/* binding */ RemoveCustomerLot)
/* harmony export */ });
/* harmony import */ var _shoppingTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(877);

const GetLotsRequest = ()=>{
    return {
        type: _shoppingTypes__WEBPACK_IMPORTED_MODULE_0__/* .GET_LOTS_REQUEST */ .sb
    };
};
const GetLotsSuccess = (lots)=>{
    return {
        type: _shoppingTypes__WEBPACK_IMPORTED_MODULE_0__/* .GET_LOTS_SUCCESS */ .Ed,
        payload: {
            lots: lots
        }
    };
};
const GetLotsFail = (error)=>{
    return {
        type: _shoppingTypes__WEBPACK_IMPORTED_MODULE_0__/* .GET_LOTS_FAIL */ .be,
        payload: {
            error: error
        }
    };
};
const AddCustomerLot = (lot)=>{
    return {
        type: _shoppingTypes__WEBPACK_IMPORTED_MODULE_0__/* .ADD_CUSTOMER_LOT */ .wt,
        payload: {
            lot: lot
        }
    };
};
const RemoveCustomerLot = (id)=>{
    return {
        type: _shoppingTypes__WEBPACK_IMPORTED_MODULE_0__/* .REMOVE_CUSTOMER_LOT */ .vu,
        payload: {
            id: id
        }
    };
};
const IncrementCountCustomerLot = (id)=>{
    return {
        type: _shoppingTypes__WEBPACK_IMPORTED_MODULE_0__/* .INCREMENT_COUNT_CUSTOMER_LOT */ .Jf,
        payload: {
            id: id
        }
    };
};
const DecrementCountCustomerLot = (id)=>{
    return {
        type: _shoppingTypes__WEBPACK_IMPORTED_MODULE_0__/* .DECREMENT_COUNT_CUSTOMER_LOT */ .iW,
        payload: {
            id: id
        }
    };
};


/***/ }),

/***/ 877:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ed": () => (/* binding */ GET_LOTS_SUCCESS),
/* harmony export */   "Jf": () => (/* binding */ INCREMENT_COUNT_CUSTOMER_LOT),
/* harmony export */   "be": () => (/* binding */ GET_LOTS_FAIL),
/* harmony export */   "iW": () => (/* binding */ DECREMENT_COUNT_CUSTOMER_LOT),
/* harmony export */   "sb": () => (/* binding */ GET_LOTS_REQUEST),
/* harmony export */   "vu": () => (/* binding */ REMOVE_CUSTOMER_LOT),
/* harmony export */   "wt": () => (/* binding */ ADD_CUSTOMER_LOT)
/* harmony export */ });
const GET_LOTS_REQUEST = " GET_LOTS_REQUEST";
const GET_LOTS_SUCCESS = " GET_LOTS_SUCCESS";
const GET_LOTS_FAIL = " GET_LOTS_FAIL";
const ADD_CUSTOMER_LOT = "ADD_CUSTOMER_LOT";
const REMOVE_CUSTOMER_LOT = "REMOVE_CUSTOMER_LOT";
const INCREMENT_COUNT_CUSTOMER_LOT = "INCREMENT_COUNT_CUSTOMER_LOT";
const DECREMENT_COUNT_CUSTOMER_LOT = "DECREMENT_COUNT_CUSTOMER_LOT";


/***/ })

};
;