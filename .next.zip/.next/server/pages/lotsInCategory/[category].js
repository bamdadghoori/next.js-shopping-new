"use strict";
(() => {
var exports = {};
exports.id = 59;
exports.ids = [59,183,161,985,38,286];
exports.modules = {

/***/ 2145:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5687);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(https__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lots__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6855);





const LotsInCategory = ({ data  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_lots__WEBPACK_IMPORTED_MODULE_4__["default"], {
            lots: data
        })
    });
};
(axios__WEBPACK_IMPORTED_MODULE_2___default().defaults.httpsAgent) = new (https__WEBPACK_IMPORTED_MODULE_3___default().Agent)({
    rejectUnauthorized: false
});
const getStaticPaths = async ()=>{
    let paths = [];
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(`https://fakestoreapi.com/products`);
        paths = await response.data.map((el)=>({
                params: {
                    category: el.category.toString()
                }
            })
        );
    } catch (er) {}
    return {
        paths,
        fallback: false
    };
};
const getStaticProps = async (context)=>{
    let data = [];
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_2___default().get(`https://fakestoreapi.com/products/category/${context.params.category}`);
        data = response.data;
    } catch (er) {
        console.log(er.message);
    }
    return {
        props: {
            data
        },
        revalidate: 2
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LotsInCategory);


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 8890:
/***/ ((module) => {

module.exports = require("nextjs-progressbar");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5687:
/***/ ((module) => {

module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [626,154,855], () => (__webpack_exec__(2145)));
module.exports = __webpack_exports__;

})();