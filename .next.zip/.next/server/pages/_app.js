"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888,183,161,985,38,286];
exports.modules = {

/***/ 4965:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "@fortawesome/react-fontawesome"
var react_fontawesome_ = __webpack_require__(7197);
;// CONCATENATED MODULE: external "@fortawesome/free-regular-svg-icons"
const free_regular_svg_icons_namespaceObject = require("@fortawesome/free-regular-svg-icons");
// EXTERNAL MODULE: external "@fortawesome/free-solid-svg-icons"
var free_solid_svg_icons_ = __webpack_require__(6466);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "nextjs-progressbar"
var external_nextjs_progressbar_ = __webpack_require__(8890);
var external_nextjs_progressbar_default = /*#__PURE__*/__webpack_require__.n(external_nextjs_progressbar_);
;// CONCATENATED MODULE: ./public/components/predictSearch.tsx





const PredictSearch = ({ relatedLots , handleClose , handleLoading  })=>{
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    const handleClick = (e)=>{
        e.preventDefault();
        setLoading(true);
        handleLoading();
        handleClose();
        const id = e.currentTarget.id;
        router.push(`/lotDetails/${id}`);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            loading == true && /*#__PURE__*/ jsx_runtime_.jsx((external_nextjs_progressbar_default()), {
                color: "rgb(255, 107, 0)",
                startPosition: 0.3,
                stopDelayMs: 200,
                height: 3,
                showOnShallow: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "predict-search",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: relatedLots.length == 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "not-match-search",
                            children: "There is nothing matches your search!"
                        }) : relatedLots.map((el, i)=>{
                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-md-6",
                                id: el.id,
                                onClick: handleClick,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "lot-predict-search",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: el.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: el.image
                                            })
                                        })
                                    ]
                                })
                            }, el.id);
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const predictSearch = (PredictSearch);

;// CONCATENATED MODULE: ./public/components/searchBox.tsx









const SearchBox = ()=>{
    const lots = (0,external_react_redux_.useSelector)((state)=>state.lots
    );
    const { 0: searchValue , 1: setSearchValue  } = (0,external_react_.useState)("");
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const { 0: predictDisplay , 1: SetPredictDisplay  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    const { 0: relatedLots , 1: setRelatedLots  } = (0,external_react_.useState)([]);
    const handleChange = (e)=>{
        setSearchValue(e.target.value);
    };
    const handleClose = ()=>{
        setSearchValue("");
        SetPredictDisplay(false);
    };
    const handleClick = (e)=>{
        e.preventDefault();
        handleClose();
        if (searchValue != "") {
            setLoading(true);
            router.push(`/search/${searchValue}`);
        }
    };
    const handleKeyUp = ()=>{
        searchValue == "" ? SetPredictDisplay(false) : SetPredictDisplay(true);
        setRelatedLots(lots.filter((el, i)=>{
            return el.title.toUpperCase().includes(searchValue.toUpperCase()) || el.category.toUpperCase().includes(searchValue.toUpperCase()) || el.description.toUpperCase().includes(searchValue.toUpperCase());
        }));
    };
    const handleLoading = ()=>{
        setLoading(true);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            loading == true && /*#__PURE__*/ jsx_runtime_.jsx((external_nextjs_progressbar_default()), {
                color: "rgb(255, 107, 0)",
                startPosition: 0.3,
                stopDelayMs: 200,
                height: 3,
                showOnShallow: true
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "form-floating form-outline",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "text",
                                id: "floatingInput",
                                className: "form-control",
                                placeholder: "search",
                                value: searchValue,
                                onChange: handleChange,
                                onKeyUp: handleKeyUp,
                                autoComplete: "off"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                icon: free_solid_svg_icons_.faClose,
                                className: "close-icon",
                                onClick: handleClose
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                className: "form-label",
                                htmlFor: "floatingInput",
                                children: "Search"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        type: "button",
                        className: "btn btn-primary btn-search",
                        onClick: handleClick,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                            icon: free_solid_svg_icons_.faSearch
                        })
                    })
                ]
            }),
            predictDisplay && /*#__PURE__*/ jsx_runtime_.jsx(predictSearch, {
                handleClose: handleClose,
                handleLoading: handleLoading,
                relatedLots: relatedLots
            })
        ]
    });
};
/* harmony default export */ const searchBox = (SearchBox);

;// CONCATENATED MODULE: ./public/components/modalCount.tsx





const ModalCount = ({ lot , inventory , increment , decrement , removeLot  })=>{
    const currentLot = (0,external_react_redux_.useSelector)((state)=>state.customerLots.filter((el, i)=>{
            return el.id == lot.id;
        })
    );
    const lotCount = currentLot[0].lotCount;
    const totalPriceOfEach = lot.price * lot.lotCount;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "row modal-lot",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "col-md-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "title",
                        children: lot.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "inventory",
                        children: [
                            "Inventory: ",
                            inventory
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "price",
                        children: [
                            totalPriceOfEach,
                            "$"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "col-md-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: lot.image
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "lot-count",
                        children: [
                            lotCount > 1 ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "decrement",
                                onClick: ()=>decrement(lotCount, inventory, lot.id)
                                ,
                                children: "-"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "decrement",
                                onClick: ()=>removeLot(lot.id)
                                ,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                    icon: free_solid_svg_icons_.faTrash
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "lotCount-number",
                                children: lotCount
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "increment",
                                onClick: ()=>increment(lotCount, inventory, lot.id)
                                ,
                                children: "+"
                            })
                        ]
                    })
                ]
            })
        ]
    }, lot.id);
};
/* harmony default export */ const modalCount = (ModalCount);

// EXTERNAL MODULE: ./public/components/context.tsx
var context = __webpack_require__(3871);
// EXTERNAL MODULE: ./redux/shopping/shoppingActions.tsx
var shoppingActions = __webpack_require__(4655);
;// CONCATENATED MODULE: ./public/components/shoppingCardModal.tsx











const ShoppingCardModal = ({ closeModal  })=>{
    //@ts-ignore
    const { loggedIn  } = (0,external_react_.useContext)(context/* default */.Z);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { 0: showError , 1: setShowError  } = (0,external_react_.useState)(false);
    const { 0: showSuccess , 1: setShowSuccess  } = (0,external_react_.useState)(false);
    let lots = (0,external_react_redux_.useSelector)((state)=>state.lots
    );
    let customerLots = (0,external_react_redux_.useSelector)((state)=>state.customerLots
    );
    const increment = (lotCount, inventory, lotId)=>{
        if (lotCount <= inventory) {
            dispatch((0,shoppingActions/* IncrementCountCustomerLot */.$V)(lotId));
        }
    };
    const decrement = (lotCount, inventory, lotId)=>{
        if (lotCount > 1) {
            dispatch((0,shoppingActions/* DecrementCountCustomerLot */.iK)(lotId));
        }
    };
    const removeLot = (id)=>{
        dispatch((0,shoppingActions/* RemoveCustomerLot */.sP)(id));
    };
    const handleRegister = (e)=>{
        e.preventDefault();
        if (loggedIn == true) {
            setShowSuccess(true);
            setShowError(false);
        } else {
            setShowError(true);
            setShowSuccess(false);
        }
    };
    let totalCost = 0;
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "shopping-card-modal",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container lots-list ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "close",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                icon: free_solid_svg_icons_.faClose,
                                onClick: closeModal
                            })
                        }),
                        customerLots.length == 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "empty-basket",
                            children: "Your basket is empty "
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: customerLots.map((el, i)=>{
                                totalCost += el.price * el.lotCount;
                                //to find invntory of current lot
                                const currentLot = lots.filter((element, index)=>{
                                    return element.id == el.id;
                                });
                                const inventory = currentLot[0].rating.count;
                                return /*#__PURE__*/ jsx_runtime_.jsx(modalCount, {
                                    lot: el,
                                    removeLot: removeLot,
                                    decrement: decrement,
                                    inventory: inventory,
                                    increment: increment
                                });
                            })
                        })
                    ]
                }),
                showError == true && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "error-shopp-regist alert-danger",
                        children: "You should sign in to do this!"
                    })
                }),
                showSuccess == true && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "success-shopp-regist alert-success",
                        children: "You can't do this because the api is fake :)"
                    })
                }),
                customerLots.length != 0 && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "regist-order row",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-md-6",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "total-cost",
                                        children: [
                                            "Total Cost :",
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "price",
                                                children: [
                                                    "$",
                                                    totalCost
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-md-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn btn-regist-order",
                                        onClick: handleRegister,
                                        children: "Regsit Order"
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const shoppingCardModal = (ShoppingCardModal);

;// CONCATENATED MODULE: ./public/components/navbar.tsx














const Navbar = ()=>{
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const { 0: shoppingModal , 1: setShoppingModal  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    const totalCount = (0,external_react_redux_.useSelector)((state)=>state.totalCount
    );
    const customerLots = (0,external_react_redux_.useSelector)((state)=>state.customerLots
    );
    let lots = (0,external_react_redux_.useSelector)((state)=>state.lots
    );
    //@ts-ignore
    const { loggedIn  } = (0,external_react_.useContext)(context/* default */.Z);
    //@ts-ignore
    const { logOut  } = (0,external_react_.useContext)(context/* default */.Z);
    lots = lots.map((el)=>el.category
    );
    lots = lots.filter((el, i)=>{
        return lots.indexOf(el) == i;
    });
    const handleCategoryLink = (e, el)=>{
        e.preventDefault();
        setLoading(true);
        router.push(`/lotsInCategory/${el}`);
    };
    const handleShoppingCart = ()=>{
        setShoppingModal(!shoppingModal);
    };
    const handleLogOut = (e)=>{
        e.preventDefault();
        localStorage.removeItem("token");
        router.push("../../");
        logOut();
    };
    const closeModal = ()=>{
        setShoppingModal(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            loading && /*#__PURE__*/ jsx_runtime_.jsx((external_nextjs_progressbar_default()), {
                color: "rgb(255, 107, 0)",
                startPosition: 0.3,
                stopDelayMs: 200,
                height: 3,
                showOnShallow: true
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                className: "navbar navbar-expand-lg navbar-light ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "navbar-brand",
                            children: "Home"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "navbar-toggler",
                        type: "button",
                        "data-bs-toggle": "collapse",
                        "data-bs-target": "#navbarNav",
                        "aria-controls": "navbarNav",
                        "aria-expanded": "false",
                        "aria-label": "Toggle navigation",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "navbar-toggler-icon"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "collapse navbar-collapse",
                        id: "navbarNav",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "navbar-nav",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "nav-item about-item",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/about",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "",
                                        className: "nav-link",
                                        children: "About us"
                                    })
                                })
                            })
                        })
                    })
                ]
            }),
            shoppingModal && /*#__PURE__*/ jsx_runtime_.jsx(shoppingCardModal, {
                closeModal: closeModal
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "nav-item login-item",
                children: loggedIn == true ? /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "#",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        href: "",
                        onClick: handleLogOut,
                        className: "nav-link",
                        children: [
                            "log out ",
                            /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                icon: free_regular_svg_icons_namespaceObject.faUser
                            })
                        ]
                    })
                }) : /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: {
                        pathname: "/login"
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        href: "",
                        className: "nav-link",
                        children: [
                            "Sign in ",
                            /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                icon: free_regular_svg_icons_namespaceObject.faUser
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "nav-item nav-item-shopping-basket",
                onClick: handleShoppingCart,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "../images/download.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "badge bg-info text-dark",
                        children: totalCount
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "nav-item search-section",
                children: /*#__PURE__*/ jsx_runtime_.jsx(searchBox, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "second-nav navbar",
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "nav-item dropdown",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "dropdown-toggle",
                                href: "#",
                                id: "navbarDropdown",
                                role: "button",
                                "data-bs-toggle": "dropdown",
                                "aria-haspopup": "true",
                                "aria-expanded": "false",
                                children: "Categories"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "dropdown-menu",
                                "aria-labelledby": "navbarDropdown",
                                children: lots.map((el, i)=>{
                                    return /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "",
                                        className: "dropdown-item",
                                        onClick: (e)=>handleCategoryLink(e, el)
                                        ,
                                        children: el
                                    }, i);
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const navbar = (Navbar);

;// CONCATENATED MODULE: ./public/components/layout.tsx





const Layout = ({ children  })=>{
    const { 0: loggedIn , 1: setLoggedIn  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        const token = localStorage.getItem("token");
        if (token) {
            setLoggedIn(true);
        } else {
            setLoggedIn(false);
        }
    }, []);
    const state1 = (0,external_react_redux_.useSelector)((state)=>state.lots
    );
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(navbar, {}),
            children
        ]
    });
};
/* harmony default export */ const layout = (Layout);

;// CONCATENATED MODULE: external "next/script"
const script_namespaceObject = require("next/script");
var script_default = /*#__PURE__*/__webpack_require__.n(script_namespaceObject);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
;// CONCATENATED MODULE: external "redux-persist"
const external_redux_persist_namespaceObject = require("redux-persist");
// EXTERNAL MODULE: ./redux/shopping/shoppingTypes.tsx
var shoppingTypes = __webpack_require__(877);
;// CONCATENATED MODULE: ./redux/shopping/shoppingReducer.tsx

const initailState = {
    lots: [],
    isLoading: false,
    error: "",
    customerLots: [],
    totalCount: 0
};
const shoppingReducers = (state = initailState, action)=>{
    switch(action.type){
        //  cases to fetch lots from api :
        case shoppingTypes/* GET_LOTS_REQUEST */.sb:
            return {
                ...state,
                isLoading: true
            };
            break;
        case shoppingTypes/* GET_LOTS_SUCCESS */.Ed:
            return {
                ...state,
                lots: action.payload.lots,
                isLoading: false
            };
            break;
        case shoppingTypes/* GET_LOTS_FAIL */.be:
            return {
                ...state,
                error: action.payload.error,
                isLoading: false
            };
            break;
        case shoppingTypes/* ADD_CUSTOMER_LOT */.wt:
            return {
                ...state,
                customerLots: [
                    ...state.customerLots,
                    action.payload.lot
                ],
                totalCount: state.totalCount + parseInt(action.payload.lot.lotCount)
            };
            break;
        case shoppingTypes/* REMOVE_CUSTOMER_LOT */.vu:
            return {
                ...state,
                customerLots: state.customerLots.filter((el)=>el.id != action.payload.id
                ),
                totalCount: state.totalCount - 1
            };
            break;
        case shoppingTypes/* INCREMENT_COUNT_CUSTOMER_LOT */.Jf:
            {
                const index = state.customerLots.findIndex((el)=>el.id == action.payload.id
                );
                return {
                    ...state,
                    customerLots: [
                        ...state.customerLots.slice(0, index),
                        {
                            ...state.customerLots[index],
                            lotCount: state.customerLots[index].lotCount + 1
                        },
                        ...state.customerLots.slice(index + 1)
                    ],
                    totalCount: state.totalCount + 1
                };
                break;
            }
        case shoppingTypes/* DECREMENT_COUNT_CUSTOMER_LOT */.iW:
            {
                const index = state.customerLots.findIndex((el)=>el.id == action.payload.id
                );
                return {
                    ...state,
                    customerLots: [
                        ...state.customerLots.slice(0, index),
                        {
                            ...state.customerLots[index],
                            lotCount: state.customerLots[index].lotCount - 1
                        },
                        ...state.customerLots.slice(index + 1)
                    ],
                    totalCount: state.totalCount - 1
                };
                break;
            }
        default:
            return state;
            break;
    }
};

;// CONCATENATED MODULE: external "redux-persist/lib/storage"
const storage_namespaceObject = require("redux-persist/lib/storage");
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_namespaceObject);
;// CONCATENATED MODULE: ./redux/store.tsx




// export const store=createStore(shoppingReducers,applyMiddleware(thunk))

const persistConfig = {
    key: "root",
    storage: (storage_default())
};
//in yani bebin store.getstate az che no hast va oon no ro beriz to RootState!
const persistedReducer = (0,external_redux_persist_namespaceObject.persistReducer)(persistConfig, shoppingReducers);
// export interface RootState {
//   lots:Array<any>,
//   error:string,
//   isLoading:boolean
//   }
let store = (0,external_redux_namespaceObject.createStore)(persistedReducer, (0,external_redux_namespaceObject.applyMiddleware)((external_redux_thunk_default())));
let persistor = (0,external_redux_persist_namespaceObject.persistStore)(store);

;// CONCATENATED MODULE: external "redux-persist/integration/react"
const react_namespaceObject = require("redux-persist/integration/react");
;// CONCATENATED MODULE: ./pages/_app.tsx











function App({ Component , pageProps  }) {
    const { 0: loggedIn , 1: setLoggedIn  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        const token = localStorage.getItem("token");
        if (token) {
            setLoggedIn(true);
        } else {
            setLoggedIn(false);
        }
    }, []);
    const login = ()=>{
        setLoggedIn(true);
    };
    const logOut = ()=>{
        setLoggedIn(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: "online shop"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                src: "https://code.jquery.com/jquery-3.6.0.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                src: "https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                src: "https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.11.5/umd/popper.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
                store: store,
                children: /*#__PURE__*/ jsx_runtime_.jsx(context/* default.Provider */.Z.Provider, {
                    value: {
                        loggedIn,
                        login,
                        logOut
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.PersistGate, {
                        loading: null,
                        persistor: persistor,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(layout, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                                ...pageProps
                            })
                        })
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const _app = (App);


/***/ }),

/***/ 3871:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

//@ts-ignore
const AppContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppContext);


/***/ }),

/***/ 6466:
/***/ ((module) => {

module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 7197:
/***/ ((module) => {

module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 8890:
/***/ ((module) => {

module.exports = require("nextjs-progressbar");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [895,664,655], () => (__webpack_exec__(4965)));
module.exports = __webpack_exports__;

})();