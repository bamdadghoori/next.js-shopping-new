import { createContext } from 'react';
//@ts-ignore
 const AppContext = createContext();
 export default AppContext;